class OrderDetails {
  final int orderId;
  final String userName;
  final int distCode;
  final int appOrderNo;
  final int code;
  final String date;
  final double orderAmount;
  final String latitude;
  final String longitude;

  OrderDetails({
    required this.orderId,
    required this.userName,
    required this.distCode,
    required this.appOrderNo,
    required this.code,
    required this.date,
    required this.orderAmount,
    required this.latitude,
    required this.longitude,
  });

  Map<String, dynamic> toMap() {
    return {
      'orderId': orderId,
      'user_name': userName,
      'dist_code': distCode,
      'app_orderno': appOrderNo,
      'code': code,
      'date': date,
      'order_amount': orderAmount,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  factory OrderDetails.fromMap(Map<String, dynamic> map) {
    return OrderDetails(
      orderId: map['order_id'],
      userName: map['user_name'],
      distCode: map['dist_code'],
      appOrderNo: map['app_orderno'],
      code: map['code'],
      date: map['date'],
      orderAmount: map['order_amount'],
      latitude: map['latitude'],
      longitude: map['longitude'],
    );
  }
}

class ProductDetails {
  final int id;
  final int orderId;
  final String pcode;
  final int qty;
  final int bonus;
  final double rate;
  final double discount;

  ProductDetails({
    required this.id,
    required this.orderId,
    required this.pcode,
    required this.qty,
    required this.bonus,
    required this.rate,
    required this.discount,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'order_id': orderId,
      'pcode': pcode,
      'qty': qty,
      'bonus': bonus,
      'rate': rate,
      'discount': discount,
    };
  }

  factory ProductDetails.fromMap(Map<String, dynamic> map) {
    return ProductDetails(
      id: map['id'],
      orderId: map['order_id'],
      pcode: map['pcode'],
      qty: map['qty'],
      bonus: map['bonus'],
      rate: map['rate'],
      discount: map['discount'],
    );
  }
}
class CustomerDetails {
  int id;
  int distCode;
  int code;
  String name;
  String address;
  int areaCd;
  String active;

  CustomerDetails({
    required this.id,
    required this.distCode,
    required this.code,
    required this.name,
    required this.address,
    required this.areaCd,
    required this.active,
  });

  Map<String, dynamic> toMap() {
    return {
      'ID': id,
      'dist_code': distCode,
      'code': code,
      'name': name,
      'address': address,
      'areacd': areaCd,
      'active': active,
    };
  }

  factory CustomerDetails.fromMap(Map<String, dynamic> map) {
    return CustomerDetails(
      id: map['ID'],
      distCode: map['dist_code'],
      code: map['code'],
      name: map['name'],
      address: map['address'],
      areaCd: map['areacd'],
      active: map['active'],
    );
  }

  factory CustomerDetails.fromJson(Map<String, dynamic> json) {
    return CustomerDetails(
      id: int.parse(json['ID']),
      distCode: int.parse(json['dist_code']),
      code: int.parse(json['code']),
      name: json['name'],
      address: json['address'],
      areaCd: int.parse(json['areacd']),
      active: json['active'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'ID': id,
      'dist_code': distCode,
      'code': code,
      'name': name,
      'address': address,
      'areacd': areaCd,
      'active': active,
    };
  }
}
