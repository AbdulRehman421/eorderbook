// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'InvoiceData.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class MyDataAdapter {
  @override
  final int typeId = 4;

  @override

  @override

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MyDataAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
